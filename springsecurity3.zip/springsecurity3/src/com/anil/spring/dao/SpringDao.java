package com.anil.spring.dao;

public interface SpringDao {

	
	public void createUserAccount(String email, String password);
}
