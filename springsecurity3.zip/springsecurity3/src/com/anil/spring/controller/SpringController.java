package com.anil.spring.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.anil.spring.service.SpringService;

@Controller
public class SpringController {
	@Autowired
	SpringService springservice;
	
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView getHomePage(){
		
		ModelAndView mav = new ModelAndView("home");
		
		return mav;
		
		
	}
	
	
	//@Secured(value="{ROLE_ADMIN}")
	@RequestMapping(value="/admin",method=RequestMethod.GET)
	public ModelAndView getAdminPage(Principal principal){
		//System.out.println("LoggedinUser for /admin     "+principal.getName());
		ModelAndView mav = new ModelAndView("admin");
		
		return mav;
		
		
	}
	
	@RequestMapping(value="/reports",method=RequestMethod.GET)
	public ModelAndView getReportsPage(Principal principal){
		//System.out.println("LoggedinUser for /reports     "+principal.getName());
		ModelAndView mav = new ModelAndView("reports");
		
		return mav;
		
		
	}
	

	
	@RequestMapping(value="/dashboard",method=RequestMethod.GET)
	public ModelAndView getDashboardPage(Principal principal){
		//System.out.println("LoggedinUser for /dashboard     "+principal.getName());
		ModelAndView mav = new ModelAndView("dashboard");
		
		return mav;
		
		
	}
	
	@RequestMapping(value="/denied",method=RequestMethod.GET)
	public ModelAndView getDeniedPage(Principal principal){
		//System.out.println("LoggedinUser for /dashboard     "+principal.getName());
		ModelAndView mav = new ModelAndView("denied");
		
		return mav;
		
		
	}
	
	
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public ModelAndView getRegisterPage(Principal principal){
		//System.out.println("LoggedinUser for /dashboard     "+principal.getName());
		ModelAndView mav = new ModelAndView("register");
		
		return mav;
		
		
	}
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public ModelAndView getPostRegisterPage(@RequestParam("email") String email,@RequestParam("password") String Password){
		//System.out.println("LoggedinUser for /dashboard     "+principal.getName());
		ModelAndView mav = new ModelAndView("denied");
		System.out.println("email"+email+"password"+Password);
		
		return mav;
		
		
	}

}
