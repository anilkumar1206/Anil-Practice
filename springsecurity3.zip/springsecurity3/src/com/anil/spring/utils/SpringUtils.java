package com.anil.spring.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class SpringUtils {
	
	public static String getEncryptedPassword(final String password){
		PasswordEncoder pe = new BCryptPasswordEncoder();
		return  pe.encode(password);
	}

}
