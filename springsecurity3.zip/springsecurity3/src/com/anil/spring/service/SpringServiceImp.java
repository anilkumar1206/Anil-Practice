package com.anil.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anil.spring.dao.SpringDao;
import com.anil.spring.utils.SpringUtils;

@Service
public class SpringServiceImp implements SpringService{
	@Autowired
	private SpringDao springdao;

	@Override
	public void createUserAccount(String email, String password) {
		// TODO Auto-generated method stub
		springdao.createUserAccount(email, SpringUtils.getEncryptedPassword(password));
		
	}


}
