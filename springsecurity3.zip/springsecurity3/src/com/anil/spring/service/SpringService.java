package com.anil.spring.service;

public interface SpringService {
	

	public void createUserAccount(String email, String password);

}
